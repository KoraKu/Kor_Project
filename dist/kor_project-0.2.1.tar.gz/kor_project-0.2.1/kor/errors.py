### Class ### ------------------------------------------------------------
class NotKorFile(Exception):
    """When your file is not a .kor file
    """
    pass

class InvalidValueType(Exception):
    """
    When the value type your typed is not valid
    """
    pass